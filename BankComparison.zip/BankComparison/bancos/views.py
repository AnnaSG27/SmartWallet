from django.shortcuts import render

def index(request):
    return render(request, 'bancos/index.html')  # Renderiza la plantilla "index.html"